#include "record.h"
#include <unistd.h>

int compress_archive()
{
  //execlp("gzip", "gzip", "fichiertar");
	return 0;
}

void ajouter_flag(int bit)
{
}
