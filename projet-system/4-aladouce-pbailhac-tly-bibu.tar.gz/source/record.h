#ifndef RECORD_H_
#define RECORD_H_

int compress_archive();

void ajouter_flag(int bit);

#endif /* RECORD_H_ */
